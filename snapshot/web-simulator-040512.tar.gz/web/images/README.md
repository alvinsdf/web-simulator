# License

The assets in this directory are excluded from the Apache Software License v.2.0.  Please see the NOTICE file in this directory for more details.

